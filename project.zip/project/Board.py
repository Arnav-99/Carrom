class Player():
    def __init__(self):
        self.currScore=0