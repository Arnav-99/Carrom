import math
def dist(testX,testY,test2X,test2Y):
    return math.sqrt((test2Y-testY)**2+(test2X-testX)**2)