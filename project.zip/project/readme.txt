This is a 2-player game of Carrom. Players aim to strike down as many pegs with the striker, while avoiding fouls, to eventually win the game.

There are no non-built in Python libraries required. Image.new command was in the course notes, but was giving me an error, so I imported Image from PIL builtin instead.

The carromGame.py file is the main file that runs the game.