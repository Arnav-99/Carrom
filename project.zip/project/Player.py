class Player():
    def __init__(self):
        self.currScore=0
        self.isTurn=False
        self.hasStruckQueen=False